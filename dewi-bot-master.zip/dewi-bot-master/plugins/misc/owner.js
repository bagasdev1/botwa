exports.run = {
   usage: ['owner'],
   category: 'miscs',
   async: async (m, {
      client,
      env,
      Func
   }) => {
      client.sendContact(m.chat, [{
         name: env.owner_name,
         number: env.owner,
         about: 'Owner & Creator'
      }], m, {
         org: 'Laylaa-imup',
         website: 'https://api.Laylaa.my.id',
         email: 'contact@Laylaa.my.id'
      })
   },
   error: false,
   cache: true,
   location: __filename
}